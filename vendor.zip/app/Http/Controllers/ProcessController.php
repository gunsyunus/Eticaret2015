<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;

/**
 * Process Controller
 *
 * It is used for requests that are the only task.
 */
class ProcessController extends Controller
{
    //
}
